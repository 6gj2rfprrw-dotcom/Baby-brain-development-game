import SwiftUI
@main
struct BabyBrainGamesApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
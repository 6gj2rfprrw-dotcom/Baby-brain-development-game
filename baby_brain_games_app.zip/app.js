
/* Core app JS: games and service worker registration */
let soundEnabled = true;
function toggleSound(){ soundEnabled = !soundEnabled; document.getElementById('sound-btn').textContent = soundEnabled ? '🔊' : '🔇'; }

function showPage(id){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  const el = document.getElementById(id);
  if(el) el.classList.add('active');
  // init when needed
  if(id==='soundgame') initSoundGame();
  if(id==='musicgame') initMusicGame();
  if(id==='alphabet') initAlphabetGame();
  if(id==='vehicles') initVehiclesGame();
}

/* --- Placeholder assets: short beep WAVs in /sounds --- */
const soundBase = 'sounds/';

/* --- Sound Game --- */
const soundAnimals = [
  {name:'Cat', display:'🐱', file:'cat.wav'},
  {name:'Dog', display:'🐶', file:'dog.wav'},
  {name:'Cow', display:'🐮', file:'cow.wav'},
  {name:'Duck', display:'🦆', file:'duck.wav'},
  {name:'Lion', display:'🦁', file:'lion.wav'},
  {name:'Sheep', display:'🐑', file:'sheep.wav'}
];
let soundScore = 0;
let currentSoundTarget = null;
function initSoundGame(){
  const grid = document.getElementById('sound-game-grid');
  const target = document.getElementById('sound-target');
  grid.innerHTML='';
  const order = shuffle([...soundAnimals]);
  order.forEach(a=>{
    const d = document.createElement('div'); d.className='game-item'; d.textContent=a.display;
    d.onclick = ()=>{ if(a.name===currentSoundTarget.name){ soundScore++; document.getElementById('sound-score').innerText=soundScore; celebrate(); } initSoundGame(); };
    grid.appendChild(d);
  });
  currentSoundTarget = order[Math.floor(Math.random()*order.length)];
  target.textContent = '🔈 Playing sound...';
  playAudio(soundBase + currentSoundTarget.file);
}

/* --- Music Game --- */
const notes = { C:261.63, D:293.66, E:329.63, F:349.23, G:392.00, A:440.00, B:493.88 };
let musicScore = 0;
let currentMelody = [];
function initMusicGame(){
  const keys = document.getElementById('music-keys');
  keys.innerHTML='';
  // create keys
  Object.keys(notes).forEach(k=>{
    const btn=document.createElement('div'); btn.className='piano-key'; btn.textContent=k;
    btn.onclick = ()=>{ playTone(notes[k]); checkMelodyInput(k); };
    keys.appendChild(btn);
  });
  newMelody();
}
function newMelody(){
  // generate 3-note melody
  const opts = Object.keys(notes);
  currentMelody = [opts[rand(opts.length)], opts[rand(opts.length)], opts[rand(opts.length)]];
  document.getElementById('music-target').textContent = currentMelody.join(' - ');
  // reset user input
  userMelodyInput = [];
}
function autoplayMelody(){
  // play notes in sequence
  let delay=0;
  currentMelody.forEach((n,i)=>{
    setTimeout(()=>playTone(notes[n]), delay);
    delay += 500;
  });
}
let userMelodyInput = [];
function checkMelodyInput(k){
  userMelodyInput.push(k);
  const idx = userMelodyInput.length-1;
  if(userMelodyInput[idx] !== currentMelody[idx]){
    // wrong
    userMelodyInput = [];
    return;
  }
  if(userMelodyInput.length === currentMelody.length){
    musicScore++; document.getElementById('music-score').innerText=musicScore; celebrate();
    setTimeout(newMelody, 300);
  }
}

/* --- Alphabet Game --- */
const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
let alphaScore = 0;
let currentAlphaTarget = null;
function initAlphabetGame(){
  const grid = document.getElementById('alpha-grid');
  const target = document.getElementById('alpha-target');
  grid.innerHTML='';
  const sample = shuffle(alphabet).slice(0,12);
  sample.forEach(letter=>{
    const d=document.createElement('div'); d.className='game-item'; d.style.fontSize='2rem'; d.textContent=letter;
    d.onclick=()=>{ if(letter===currentAlphaTarget){ alphaScore++; document.getElementById('alpha-score').innerText=alphaScore; celebrate(); initAlphabetGame(); } };
    grid.appendChild(d);
  });
  currentAlphaTarget = sample[Math.floor(Math.random()*sample.length)];
  target.textContent = '🔈 Listen for the letter sound';
  speak(currentAlphaTarget);
}

/* --- Vehicle Sounds Game --- */
const vehicles = [
  {name:'Car', display:'🚗', file:'car.wav'},
  {name:'Train', display:'🚆', file:'train.wav'},
  {name:'Ambulance', display:'🚑', file:'ambulance.wav'},
  {name:'Helicopter', display:'🚁', file:'heli.wav'},
  {name:'Motorbike', display:'🏍️', file:'bike.wav'},
  {name:'Boat', display:'🛥️', file:'boat.wav'}
];
let vehScore=0, currentVeh=null;
function initVehiclesGame(){
  const grid = document.getElementById('veh-grid');
  const target = document.getElementById('veh-target');
  grid.innerHTML='';
  const order = shuffle([...vehicles]);
  order.forEach(v=>{
    const d=document.createElement('div'); d.className='game-item'; d.textContent=v.display;
    d.onclick=()=>{ if(v.name===currentVeh.name){ vehScore++; document.getElementById('veh-score').innerText=vehScore; celebrate(); } initVehiclesGame(); };
    grid.appendChild(d);
  });
  currentVeh = order[Math.floor(Math.random()*order.length)];
  target.textContent = '🔈 Playing vehicle sound...';
  playAudio(soundBase + currentVeh.file);
}

/* --- Audio helpers --- */
function playAudio(src){
  if(!soundEnabled) return;
  const a = new Audio(src);
  a.play().catch(()=>{ /* ignore autoplay block on iOS until user interacts */});
}
function playTone(freq, duration=300){
  if(!soundEnabled) return;
  try{
    const ctx = new (window.AudioContext || window.webkitAudioContext)();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type='sine';
    o.frequency.value = freq;
    o.connect(g); g.connect(ctx.destination);
    o.start();
    g.gain.setValueAtTime(0.001, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.2, ctx.currentTime + 0.01);
    setTimeout(()=>{ g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration/1000); o.stop(ctx.currentTime + duration/1000 + 0.02); ctx.close(); }, duration);
  }catch(e){}
}

function celebrate(){
  const c = document.getElementById('celebration');
  c.textContent='🎉';
  c.style.display='block';
  setTimeout(()=>{ c.style.display='none'; },700);
}

/* speech */
function speak(text){
  if('speechSynthesis' in window){
    const u = new SpeechSynthesisUtterance(text);
    window.speechSynthesis.cancel(); // stop prior
    window.speechSynthesis.speak(u);
  }
}

/* util */
function shuffle(a){ return a.sort(()=>Math.random()-0.5); }
function rand(n){ return Math.floor(Math.random()*n); }

/* small helper for user actions requiring audio on iOS: */
window.addEventListener('click', ()=>{ try{ if((window.AudioContext || window.webkitAudioContext) && !window.__audioStarted){ window.__audioStarted = true; new (window.AudioContext || window.webkitAudioContext)(); } }catch(e){} });

/* Service worker registration */
if('serviceWorker' in navigator){
  navigator.serviceWorker.register('sw.js').catch(()=>{});
}

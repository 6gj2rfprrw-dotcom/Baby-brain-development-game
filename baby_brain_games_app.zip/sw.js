
const CACHE_NAME = 'baby-brain-games-v1';
const OFFLINE_ASSETS = [
  '/',
  '/index.html',
  '/styles.css',
  '/app.js',
  '/manifest.json',
  '/images/logo-192.png',
  '/images/logo-512.png'
];
// add all sounds to cache dynamically
self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => cache.addAll(OFFLINE_ASSETS))
  );
});
self.addEventListener('fetch', event => {
  event.respondWith(
    caches.match(event.request).then(resp => {
      return resp || fetch(event.request).then(r => {
        return caches.open(CACHE_NAME).then(cache => { cache.put(event.request, r.clone()); return r; })
      }).catch(()=>caches.match('/index.html'));
    })
  );
});
